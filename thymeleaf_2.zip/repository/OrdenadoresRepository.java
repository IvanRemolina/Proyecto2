package com.example.thymeleaf_2.repository;

import com.example.thymeleaf_2.model.Ordenadores;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrdenadoresRepository extends JpaRepository<Ordenadores, Long> {
}
