package com.example.thymeleaf_2.repository;

import com.example.thymeleaf_2.model.Menu;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MenuRepository extends JpaRepository<Menu, Long> {
}
